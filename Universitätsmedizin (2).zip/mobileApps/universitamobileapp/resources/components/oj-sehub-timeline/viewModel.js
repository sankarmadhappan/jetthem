/**
  Copyright (c) 2018, Oracle and/or its affiliates.
  The Universal Permissive License (UPL), Version 1.0
*/
'use strict';

define(['ojs/ojcore', 'knockout'],
  function(oj, ko) {
    function model(context) {


      var self = this;

      self.args = JSON.stringify(context.properties.args);

      self.composite = context.element;

      self.properties = context.properties;

      self.timelineDataVariable = self.properties.dataArray;
      
   

      console.log("Context", context);
      console.log(document.getElementById(context.uniqueId));


      ///// calling hexagon creation script only when the component is ready

      self.bindingsApplied = function(context) {




        console.log("Properties", self.properties);

        console.log("In Bindings Applied");
        var busyContext = oj.Context.getContext(context.element).getBusyContext();

        busyContext.whenReady().then(function() {



        });

      }




    }

    return model;
  }
)