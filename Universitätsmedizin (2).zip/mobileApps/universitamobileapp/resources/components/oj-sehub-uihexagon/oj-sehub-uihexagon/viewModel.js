/**
  Copyright (c) 2018, Oracle and/or its affiliates.
  The Universal Permissive License (UPL), Version 1.0
*/
'use strict';

define(['ojs/ojcore', 'knockout'],
  function(oj, ko) {
    function model(context) {


      var self = this;

      self.args = JSON.stringify(context.properties.args);

      self.composite = context.element;

      self.properties = context.properties;


      self.data = self.properties.dataArray;
      
      if (self.properties.columns === 4) {

        console.log("Value Columns", self.properties.columns);

        self.columns = "hexagon";
        self.columnsContainer = "hexagon-container";

      } else {
        self.columns = "hexagon3";
        self.columnsContainer = "hexagon3-container";
      }
      
      for(var i =0 ; i< self.data.length ; i++) {
        
        
        self.data[i]['class'] = self.data[i]['color'] + " " + self.columns;
        
        
      }



      


      console.log("Context", context);
      console.log(document.getElementById(context.uniqueId));


      ///// calling hexagon creation script only when the component is ready

      self.bindingsApplied = function(context) {




        console.log("Value Columns", self.properties.columns, self.columns,
          self.columnsContainer);

        console.log("In Bindings Applied");
        var busyContext = oj.Context.getContext(context.element).getBusyContext();

        busyContext.whenReady().then(function() {



        });

      }


      self.clickEvent = function(par1) {

        console.log("In Click Hexagon", arguments);
        var eventParams = {
          'bubbles': true,
          'cancelable': false,
          'detail': {
            'nameOfHexagon': par1
          }
        };

        //Raise the custom event
        self.composite.dispatchEvent(new CustomEvent('hexagonSelected',
          eventParams));

      }


    }

    return model;
  }
)