define([], function() {
  'use strict';

  var PageModule = function PageModule() {};

    PageModule.prototype.Data = function (par1) {
    
    console.log("In Data",par1);
    
    console.log("detail -> ",par1.detail);
    var title =par1.detail.nameOfHexagon.title;
    console.log("tiitle -> ",title);
    
    return title;
    
    };
    
  return PageModule;
});
