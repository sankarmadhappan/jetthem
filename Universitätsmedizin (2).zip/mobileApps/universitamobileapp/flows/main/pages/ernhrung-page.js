define([], function() {
  'use strict';

  var PageModule = function PageModule() {};
  
  PageModule.prototype.changeStyle=function(selected)
  
  {
    var select=selected;
    console.log("style  -> ",select);
    if(select=="Tag")
    {
      document.getElementById("Tag").style.background="linear-gradient(to bottom right, #6eca7c 0%, #008889 100%)";
      document.getElementById("Woche").style.background="inherit"; 
      document.getElementById("Monat").style.background="inherit"; 
    }
    if(select=="Woche")
    {
      console.log("inside Woche");
      document.getElementById("Woche").style.background="linear-gradient(to bottom right, #6eca7c 0%, #008889 100%)";
      document.getElementById("Tag").style.background="inherit"; 
      document.getElementById("Monat").style.background="inherit"; 
    }
    if(select=="Monat")
    {
      
      document.getElementById("Monat").style.background="linear-gradient(to bottom right, #6eca7c 0%, #008889 100%)";
     document.getElementById("Woche").style.background="inherit"; 
      document.getElementById("Tag").style.background="inherit"; 
    }
    
  }

  return PageModule;
});
