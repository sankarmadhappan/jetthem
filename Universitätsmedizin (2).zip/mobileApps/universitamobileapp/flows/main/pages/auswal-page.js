define(['jquery','ojs/ojdialog'], function($) {
  'use strict';

  var PageModule = function PageModule() {};
  
  PageModule.prototype.getList=function(Data)
  {
    console.log("Sub Category List -> ",Data);
    var arr=[];
    var length=Data.length;
    if(length>5)
    {
      length=5;
    }
    for(var i=0;i<length;i++)
    {
      
      var item={};
      item.id=Data[i].ITEM_ID;
      item.Name=Data[i].ITEM;
      console.log("Item -> ",item);
      arr.push(item);
      
    } 
    console.log(" list ->",arr);
    return arr;
  }

  PageModule.prototype.Data = function (par1) {
    
    console.log("In Data",par1);
    
    };
     PageModule.prototype.test = function (data,$page) {
    
    console.log("Inside function call ",data.Name);
    $page.variables.id=data.id;
    $page.variables.Name=data.Name;
    $page.listeners.listSelection(data.id,data.Name);
    
    };
    PageModule.prototype.showDialogBox=function()
  {
     document.getElementById('modalDialog1').open();
      $('#closebt').show();
  }
    PageModule.prototype.disableDialogBox=function()
  {
     document.getElementById('modalDialog1').close();
      $('#closebt').hide();
  }

  return PageModule;
});
