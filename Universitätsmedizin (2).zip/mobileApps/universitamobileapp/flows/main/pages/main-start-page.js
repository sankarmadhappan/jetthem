define(['ojs/ojcore','ojs/ojanimation'], function(oj) {
  'use strict';

  var self;

  var PageModule = function PageModule() {

    self = this;
    // Keep track of whether the front or back is showing
    self.showingFront = true;
  };


  PageModule.prototype.Animate = function() {
    
    console.log("Animate");
    var elem = document.getElementById('animatable');

    // Determine startAngle and endAngle
    var startAngle = self.showingFront ? '0deg' : '180deg';
    var endAngle = self.showingFront ? '180deg' : '0deg';

    // Animate the element
    
    oj.AnimationUtils['flipOut'](elem, {
      'flipTarget': 'children',
      'persist': 'all',
      'startAngle': startAngle,

      'endAngle': endAngle
    });

    self.showingFront = !self.showingFront;
    
  };

  return PageModule;
});