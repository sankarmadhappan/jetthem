define(['jquery', 'ojs/ojcore', 'ojs/ojoffcanvas'], function($, oj) {
  'use strict';

  var FlowModule = function FlowModule() {};
  
  FlowModule.prototype.toggleDrawer = function(id) {
    var offcanvas = {
      "selector": id,
      "edge": "start",
      "displayMode": "push",
      "modality": "modal"
    };

    oj.OffcanvasUtils.toggle(offcanvas);
  };
  
  return FlowModule;
});