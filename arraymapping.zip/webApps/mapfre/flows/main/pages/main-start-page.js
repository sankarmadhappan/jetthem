define([], function() {
  'use strict';

  var PageModule = function PageModule() {};
  
  
  PageModule.prototype.createObj = function (data) {
    
    var obj = {};
    
    obj.token = data;
    
    return obj;
    
  }

  return PageModule;
});
