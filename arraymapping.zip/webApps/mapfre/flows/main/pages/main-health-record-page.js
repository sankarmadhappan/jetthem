define(['ojs/ojcore','ojs/ojarraydataprovider'], function(oj) {
  'use strict';

  var PageModule = function PageModule() {};
  
  PageModule.prototype.dataPayload = function (data) {
    
    console.log("Payload", data);
    
    
     var payload = JSON.parse(data['result']['payload']);
     
     var report = payload.Report.split("\'").join('\"');
     
     console.log("report", report);
     
     var obj = {};
     obj.Patient_ID = payload.Patient_ID;
     obj.LabReport_ID = payload.LabReport_ID;
     obj.Report = JSON.parse(report) ;
     obj.Report_Name = payload.Report_Name;
     obj.Date = payload.Date;
     
     console.log("Object Data", obj);
     
    return obj;
  };
  
  
     PageModule.prototype.createDataProvider121 = function (data) {
    
    console.log("Data", data);
     
    var arrayData = new oj.ArrayDataProvider(data, {keyAttributes: 'parameterName', implicitSort: [{attribute: 'parameterName', direction: 'ascending'}]});
    
    console.log("arrayData", arrayData);
    
    return arrayData;
   
  
  };

  return PageModule;
});
